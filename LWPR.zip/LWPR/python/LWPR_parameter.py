__author__ = 'Silvia'
# LWPR parameters configuration for 2-joints robot

from lwpr import *
from numpy import *

def lwpr_param2j(self, n_joints):

    model = [0 for k in range(n_joints)]

    for i in range(n_joints):

        model[i] = LWPR(4, 1)
        # joint i parameters
        model[i].init_D = 4
        model[i].init_alpha = ones(10)*10
        model[i].init_lambda = 0.995
        model[i].tau_lambda = 0.5
        model[i].final_lambda = 0.9995
        model[i].w_prune= 0.9
        model[i].w_gen = 0.2
        model[i].diag_only = 1
        model[i].update_D = 1
        model[i].meta = 0
        model[i].meta_rate = 0.3
        model[i].add_threshold = 0.95
        model[i].kernel = "Gaussian"
    return model