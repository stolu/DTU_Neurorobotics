# Test lwpr for Fable - Module 17
# Author Silvia Tolu - 25.06.2015

from lwpr import *
from numpy import *
from random import *
from math import *
import numpy as np
#import sys
#sys.path.append("/home/slyto/PycharmProjects/LWPRandFable")
n_iter = 30
n_joints = 2
model0 = LWPR(5, 1)
model1 = LWPR(5, 1)

model0.init_D = 50*eye(5)
model0.init_alpha = 250*ones([5, 5])

model1.init_D = 50*eye(5)
model1.init_alpha = 250*ones([5, 5])
torqLWPR = np.zeros((n_joints, n_iter+1), dtype=np.double)
torquestot = np.zeros((n_joints, n_iter+1), dtype=np.double)
torquestot[0] = loadtxt("torquestotmodel0.txt")
torquestot[1] = loadtxt("torquestotmodel1.txt")
print("torquestot0: ", torquestot[0])
print("torquestot0: ", torquestot[1])

data_lwpr0 = loadtxt("dataforlwprmodel0.txt")
data_lwpr1 = loadtxt("dataforlwprmodel1.txt")

#print("data_lwpr0: ", data_lwpr0[0, 0:2])
#print("size:", size(data_lwpr0))

#print("\n")
#print("data_lwpr1: ", data_lwpr1[1][30])
#print("\n")
for n in range(7):
    for i in range(n_iter):
 #   for m in range(n_joints):
        model0.update(data_lwpr0[i, 0:5], np.matrix(torquestot[0, i]))
        model1.update(data_lwpr1[i, 0:5], np.matrix(torquestot[1, i]))
        torqLWPR[0, i] = model0.predict((data_lwpr0[i, 0:5]))
        torqLWPR[1, i] = model1.predict((data_lwpr1[i, 0:5]))

print("torqLWPR0:", torqLWPR[0])
print("torqLWPR1:", torqLWPR[1])
