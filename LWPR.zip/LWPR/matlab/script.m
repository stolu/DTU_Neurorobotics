njoints = 1;
nin = 2;
beta = 5 * power(10, -5);
mlc = NRP_MLandC(njoints,nin,beta);

R = 0.1 * rand(10000,1);
x1 = rand(10000,1);
x2 = rand(10000,1);
yR = zeros(10000,njoints);
cR = zeros(10000,njoints);
yI = zeros(10000,1);

for i = 1 : 10000
   yI(i) = max([exp(-10.0 * x1(i) * x1(i)), exp(-50.0 * x2(i) * x2(i)),...
               1.25 * exp(-5.0*(x1(i) * x1(i) + x2(i) * x2(i)))]);% + R(i);
   mlc.ML_update([x1(i) x2(i)]',yI(i) + R(i));
   %mlc.ML_update([x1(i) x2(i); x1(i) x2(i)]',[yI(i) + R(i) yI(i)] + R(i));
end

for i = 1 : 1
   for j = 1 : 10000
      k = j;
      [yR(k), cR(k)] = mlc.ML_prediction([x1(j) x2(j)]', yI(k));
      %[yR(k,:), cR(k,:)] = mlc.ML_prediction([x1(i) x2(j); x1(i) x2(j)]', [yI(k) yI(k)]);
   end
end

mlc.ML_free();

figure(1), plot(yI)
figure(2), plot(yR)
figure(3), plot(yR+cR)
