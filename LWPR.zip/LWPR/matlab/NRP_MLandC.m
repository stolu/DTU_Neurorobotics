classdef NRP_MLandC
    properties 
        njoints = []
        nin = []
        beta = []
        models = struct
        cWeights = struct
        pWeights = struct
    end
    methods
        
        function obj = NRP_MLandC(njoints,nin,beta)
            obj.njoints = njoints;
            obj.nin = nin;
            obj.beta = beta;
            obj.models = struct;
            obj.models.model = lwpr_init(obj.nin, 1 ,'name','lwpr_internal_MODEL');
            for i = 1 : obj.njoints
                obj.models(i).model = lwpr_init(obj.nin, 1 ,'name','lwpr_internal_MODEL');
                obj.models(i).model = lwpr_set(obj.models(i).model,'init_D',50);
                obj.models(i).model = lwpr_set(obj.models(i).model,'init_alpha',ones(obj.nin)*250);
                obj.models(i).model = lwpr_set(obj.models(i).model,'init_lambda',0.995);
                obj.models(i).model = lwpr_set(obj.models(i).model,'tau_lambda',0.5);
                obj.models(i).model = lwpr_set(obj.models(i).model,'final_lambda',0.9995);
                obj.models(i).model = lwpr_set(obj.models(i).model,'w_prune',0.9);
                obj.models(i).model = lwpr_set(obj.models(i).model,'w_gen',0.2);
                obj.models(i).model = lwpr_set(obj.models(i).model,'diag_only',1);
                obj.models(i).model = lwpr_set(obj.models(i).model,'update_D',1);
                obj.models(i).model = lwpr_set(obj.models(i).model,'meta',0);
                obj.models(i).model = lwpr_set(obj.models(i).model,'meta_rate',0.3);
                obj.models(i).model = lwpr_set(obj.models(i).model,'add_threshold',0.95);
                obj.models(i).model = lwpr_set(obj.models(i).model,'kernel','Gaussian');
                obj.models(i).model = lwpr_storage('Store',obj.models(i).model);
                obj.cWeights(i).data = [];
                obj.pWeights(i).data = [];
            end
        end
        
        function [output_ml, output_C] = ML_prediction(obj, inputML, fbacktorq)
            output_ml = zeros(1,obj.njoints);
            output_C = zeros(1,obj.njoints);
            for i = 1 : obj.njoints
                [output_ml(i), wt] = lwpr_predict(obj.models(i).model,inputML(:,i));
                if (~isempty(wt))
                    if (length(obj.cWeights(i).data) <= length(wt))
                        obj.cWeights(i).data = [obj.cWeights(i).data; zeros(1,(length(wt) - length(obj.cWeights(i).data)))'];
                        obj.pWeights(i).data = [obj.pWeights(i).data; zeros(1,(length(wt) - length(obj.pWeights(i).data)))'];
                        obj.cWeights(i).data = obj.pWeights(i).data + (obj.beta * (fbacktorq(i) * wt))';
                        obj.pWeights(i).data = obj.cWeights(i).data;
                    end
                    output_C(i) = obj.cWeights(i).data' * wt';
                end
            end
        end
                
        
        function ML_update(obj, inputML, train_MLoutput)
            for i = 1 : obj.njoints
                obj.models(i).model = lwpr_update(obj.models(i).model, inputML(:,i), train_MLoutput(i));
            end
        end
        
        function ML_free(obj)
            for i = 1 : obj.njoints
                obj.models(i).model = lwpr_storage('GetFree',obj.models(i).model);
            end
        end
    end
end
