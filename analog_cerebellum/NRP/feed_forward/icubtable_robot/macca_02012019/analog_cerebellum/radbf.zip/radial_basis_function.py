########################################################### 
			 # RADIAL BASIS FUNCTION #
########################################################### 

# -*- coding: utf-8 -*-
"""
This file contains the implementation of a radial basis function encoding of a float array input. In this case the input array represents the current or the 
desired positions of the Fable robot joints and their values are encoded in a list of AC source amplitudes to be input to the mossy fibers of the spiking
cerebellum 
"""
# pragma: no cover

__author__ = 'Elisa Massi'

import matplotlib.pyplot as plt
import numpy as np
import random
import math

class RBF:

	def __init__(self, input, total_n_neurons):
		# Variables initialization
		self.total_range_position     = np.pi
		self.n_neurons_curr           = total_n_neurons/2 # ratio of neurons devoted to the current or desired position		
		self.input_position_current = input # array of floats
		
		self.ac_source_amplitude_max = 1.0
		self.ac_source_amplitude_min = 0.0
		self.input_current_MF_max = 16.57
		self.input_current_MF_min = 0.0

		self.ac_source_amplitude = []
		self.input_voltage_MF    = []
		self.ac_source_final = []
		self.sub_range_current      = []
		self.sub_range_current_mean = []

		self.n_input_position_current = len(self.input_position_current)
		self.delta_range_current = self.total_range_position/self.n_neurons_curr
		self.std_current         = self.delta_range_current/2
	
	def function(self):
		# Calculate position intervals for RBFs 
		left_limit   = -self.total_range_position/2
		right_limit  =  -self.total_range_position/2 + self.delta_range_current
		for i in range(0, self.n_neurons_curr):
			self.sub_range_current.append([left_limit, right_limit])
			self.sub_range_current_mean.append((left_limit + right_limit)/2)
			left_limit  = right_limit
			right_limit = right_limit + self.delta_range_current

		# Caculate AC source_amplitude for each neuron depending on the current input position
		for i in range(0, self.n_input_position_current):
			val2 = []
			for j in range(0, self.n_neurons_curr):
				val1 = math.pow((self.input_position_current[i]-self.sub_range_current_mean[j])/self.std_current, 2)
				val1bis = math.exp(- val1)
				# Scaling the AC source amplitude --->>> new_value = ( (old_value - old_min) / (old_max - old_min) ) * (new_max - new_min) + new_min #
				val2.append(((val1bis - self.ac_source_amplitude_min) / (self.ac_source_amplitude_max - self.ac_source_amplitude_min)) * (self.input_current_MF_max - self.input_current_MF_min) + self.input_current_MF_min)
			self.ac_source_amplitude.append(val2)
	
	def plot_RBF(self):
		#plt.plot( self.sub_range_current_mean , self.ac_source_amplitude[1][:], 'r.')
		plt.plot( self.input_position_current , [np.linspace(0, 10, 100, endpoint=True) ]*len(self.input_position_current), 'gx', self.sub_range_current_mean , self.ac_source_amplitude[0][:], 'b.', self.sub_range_current_mean , self.ac_source_amplitude[1][:], 'r.')
		plt.gcf().set_size_inches(8,3)
		plt.gcf().tight_layout()
		plt.title('RBFs output')
		plt.xlabel('Angular position (radiants)')
		plt.ylabel('AC source amplitude (mA)')
		plt.show()

	
		



